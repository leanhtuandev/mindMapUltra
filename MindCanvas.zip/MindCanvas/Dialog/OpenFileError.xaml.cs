﻿using Windows.UI.Xaml.Controls;

// https://go.microsoft.com/fwlink/?LinkId=234238 上介绍了“内容对话框”项模板

namespace MindCanvas.Dialog
{
    public sealed partial class OpenFileError : ContentDialog
    {
        public OpenFileError()
        {
            this.InitializeComponent();
        }
    }
}
